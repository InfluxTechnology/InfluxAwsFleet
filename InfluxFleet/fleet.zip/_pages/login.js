module.exports = {
    html: async function () {
        var html =
            "<div id='navigation'></div>\n" +
            "<div id='dashboardcontainer'>\n" +
            "<div id='caption'>Login</div>\n";


        html += "</div>\n";

        return html;
    }
}