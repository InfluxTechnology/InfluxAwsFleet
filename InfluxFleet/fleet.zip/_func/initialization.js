const AwsAccessKey = 'AKIA3H7N5Y3NQVSLIPMC';
const AwsSecretKey = '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';
const AwsRegion = 'eu-central-1';
const AwsBucket = 'influxj1939';
const AwsS3ApiVersion = '2006-03-01';

module.exports = {
    AwsAccessKey, AwsSecretKey, AwsRegion, AwsBucket, AwsS3ApiVersion,
}
